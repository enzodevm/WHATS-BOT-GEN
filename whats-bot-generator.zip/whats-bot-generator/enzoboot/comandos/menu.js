const fs = require('fs');
const path = require('path');

module.exports = async (sock, m) => {
  const comandos = fs.readdirSync(__dirname)
    .filter(x => x !== 'menu.js' && x.endsWith('.js'))
    .map((x, i) => `${i + 1}. !${x.replace('.js', '')}`)
    .join('\n');

  await sock.sendMessage(m.key.remoteJid, {
    text: `📋 *Menu de Comandos:*\n\n${comandos}`
  });
};