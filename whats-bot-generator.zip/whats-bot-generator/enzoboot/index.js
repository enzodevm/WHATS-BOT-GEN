const { default: makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const { state, saveState } = useSingleFileAuthState('./auth.json');

async function iniciarBot() {
  const sock = makeWASocket({ auth: state, printQRInTerminal: true });
  sock.ev.on('creds.update', saveState);

  const comandos = {};
  const pasta = path.join(__dirname, 'comandos');
  fs.readdirSync(pasta).forEach(arquivo => {
    if (arquivo.endsWith('.js')) {
      const nome = arquivo.replace('.js', '');
      comandos['!' + nome] = require(path.join(pasta, arquivo));
    }
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const m = messages[0];
    const texto = m.message?.conversation || m.message?.extendedTextMessage?.text;
    if (!texto) return;

    const cmd = comandos[texto.trim()];
    if (cmd) {
      await cmd(sock, m);
    }
  });
}

iniciarBot();