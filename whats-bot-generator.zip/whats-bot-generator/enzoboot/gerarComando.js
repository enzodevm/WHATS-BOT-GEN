const fs = require('fs');
const path = require('path');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log('🛠️ Criador de Comandos para seu Bot');

rl.question('📝 Nome do comando (sem "!"): ', (nome) => {
  rl.question('💬 Mensagem de resposta: ', (mensagem) => {
    const filePath = path.join(__dirname, 'comandos', `${nome}.js`);
    if (fs.existsSync(filePath)) {
      console.log('❌ Comando já existe!');
      rl.close();
      return;
    }

    const codigo = `
module.exports = async (sock, m) => {
  await sock.sendMessage(m.key.remoteJid, { text: \`${mensagem}\` });
};
`.trim();

    fs.writeFileSync(filePath, codigo);
    console.log(`✅ Comando "!${nome}" criado com sucesso!`);
    rl.close();
  });
});