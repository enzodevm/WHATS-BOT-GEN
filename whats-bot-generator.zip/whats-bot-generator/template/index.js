const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

async function iniciarBot() {
  const { version } = await fetchLatestBaileysVersion();
  const { state, saveCreds } = await useMultiFileAuthState('./auth');

  const sock = makeWASocket({
    version,
    auth: state,
    browser: ['Ubuntu', 'Chrome', '22.04.4']
  });

  sock.ev.on('creds.update', saveCreds);

  // 🔐 Mostrar QR manualmente
  sock.ev.on('connection.update', ({ connection, qr }) => {
    if (qr) {
      try {
        const qrcode = require('qrcode-terminal');
        console.log('📷 ESCANEIE O QR CODE ABAIXO COM O WHATSAPP:');
        qrcode.generate(qr, { small: true });
      } catch (e) {
        console.log('❗ ERRO: Biblioteca "qrcode-terminal" não instalada.');
        console.log('👉 Execute: npm install qrcode-terminal');
      }
    }

    if (connection === 'open') {
      console.log('✅ Conectado com sucesso!');
    }

    if (connection === 'close') {
      console.log('❌ Conexão encerrada!');
    }
  });

  // 📦 Carregar comandos
  const comandos = {};
  const pasta = path.join(__dirname, 'comandos');
  fs.readdirSync(pasta).forEach(arquivo => {
    if (arquivo.endsWith('.js')) {
      const nome = arquivo.replace('.js', '');
      comandos['!' + nome] = require(path.join(pasta, arquivo));
    }
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const m = messages[0];
    const texto = m.message?.conversation || m.message?.extendedTextMessage?.text;
    if (!texto) return;

    const cmd = comandos[texto.trim()];
    if (cmd) {
      await cmd(sock, m);
    }
  });
}

iniciarBot();
